﻿

document.addEventListener('DOMContentLoaded', function () { onDeviceReady(); });

function onDeviceReady() {
    
    document.getElementById("txtAddress").focus();

    document.getElementById("btnGetLatLon").addEventListener("click", function () { goToSSF(document.getElementById("txtAddress").value) } );

    function goToSSF(location){
        if(!!location){
            var newURL = "http://spacestationfinder.com/results.html?loc=" + location;
            chrome.tabs.create({ url: newURL });
        } else { alert('You must enter a location') }
    }
};